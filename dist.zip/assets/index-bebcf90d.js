import{_ as e,a as c,o as n}from"./index-dce3d6b9.js";const o={};function r(t,a){return n(),c("div",null," 嗨嗨嗨，我是九重天页面 ")}const _=e(o,[["render",r]]);export{_ as default};
