import{_ as e,a as c,o as n}from"./index-a109996d.js";const o={};function r(t,a){return n(),c("div",null," 账号管理 ")}const _=e(o,[["render",r]]);export{_ as default};
