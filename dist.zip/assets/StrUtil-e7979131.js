const n=t=>!t||/^\s*$/.test(t)||t.length===0,o=t=>!n(t);export{o as a,n as i};
