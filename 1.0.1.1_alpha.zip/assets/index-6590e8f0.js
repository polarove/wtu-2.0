import{_ as e,a as c,o as n}from"./index-8169ae05.js";const o={};function r(t,a){return n(),c("div",null," 账号管理 ")}const _=e(o,[["render",r]]);export{_ as default};
